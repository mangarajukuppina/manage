let table=document.getElementById("table")
console.log(table);
let td=document.getElementById("td")
console.log(td);
